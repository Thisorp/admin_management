package com.example.adminmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
